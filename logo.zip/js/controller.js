// Controllar JavaScript Document


productList.controller('productListCtrl', function($scope, $http) {
  $http.get("json/product_list.json")
  .then(function(response) {
    $scope.products = response.product;
    //console.log($scope.products);
  });
});